# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.7.18)
# Datenbank: callingallpapers
# Erstellt am: 2017-08-30 06:04:05 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Export von Tabelle cfp
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cfp`;

CREATE TABLE `cfp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(60) DEFAULT NULL,
  `dateCfpStart` datetime DEFAULT NULL,
  `dateCfpEnd` datetime DEFAULT NULL,
  `uri` text,
  `name` text,
  `timezone` text,
  `dateEventStart` datetime DEFAULT NULL,
  `dateEventEnd` datetime DEFAULT NULL,
  `description` text,
  `eventUri` text,
  `iconUri` text,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `location` text,
  `tags` text,
  `lastUpdate` datetime DEFAULT NULL,
  `source` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cfp_hash_uindex` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Export von Tabelle user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `user` text,
  `token` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_uindex` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
